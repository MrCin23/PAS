package pl.lodz.p.mvc.model.user;

public enum Role {
    ADMIN,
    RESOURCE_MANAGER,
    CLIENT

}
